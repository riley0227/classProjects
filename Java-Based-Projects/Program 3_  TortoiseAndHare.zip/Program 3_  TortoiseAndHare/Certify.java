/**
 *  Program #3
 *  Certify class certifes my program
 *  CS160-3
 *  03/06/2022
 *  @author  Riley Thompson and Patty
 */
public class Certify {
    public static void main(String[] args) 
    {
       // Print the following line if you got part 1 working, ran some races, and submitted an image to prove this.  -- 10 points
       System.out.println("I certify on my honor that I ran the Race code in part one.");
 
       // Print the following line--filling in your racers--if you added, raced two new racer types in part 2, and submitted an image to prove this.  -- 10 points
       System.out.println("My new racer classes are Bee and Dragon classes");
 
       // Print the following line if you added the morph method to all racers in part 2, and submitted images to prove this. -- 15 points
       System.out.println("The action added is morph.");
    }
}