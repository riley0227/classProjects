package edu.sdsu.cs160l.convertingtogenerics;

import edu.sdsu.cs160l.calculator.Calculator;

public class IntegerCalculator implements Calculator<Integer> {
	
	@Override
	public Integer add(Integer a, Integer b) {
			return a + b;
		}

		@Override
		public Integer sub(Integer a, Integer b) {
			return a - b;
		}

		@Override
		public Integer div(Integer a, Integer b) throws ArithmeticException {
			if (b == 0) {
				throw new ArithmeticException("b cannot be 0");
			}
			return a / b;
		}

		@Override
		public Integer mul(Integer a, Integer b) {
			return a * b;
		}
		
}
