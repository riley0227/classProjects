package edu.sdsu.cs160l.calculator;

import edu.sdsu.cs160l.convertingtogenerics.DoubleCalculator;

/**
 * TODO change MathOperation class so that it has a dependency on DoubleCalculator class and not SimpleCalculator
 *  what you also need to do is change the method signatures from int to double.
 *
 */
public class MathOperations {

    private Calculator<Double> calculator;

    public MathOperations() {
        // TODO change this to use DoubleCalculator
        this.calculator = new DoubleCalculator();
    }

    // Do not change this to double, let it be int only
    public double factorial(int n){
        double factorial = 1;
        for(int i=2;i<=n;i++){
            factorial = calculator.mul(factorial, Double.valueOf(i));
        }
        return factorial;
    }

    public double average(double[] arr){
        double sum=0;
        for(double i : arr){
            sum = calculator.add(sum, i);
        }

        return calculator.div(sum, Double.valueOf(arr.length));
    }

    // Make sure the second variable is int only
    // the signature should look like double power(double a, int b)
    public double power(double a, int b){
        double res = 1;
        for(int i=1;i<=b;i++){
            res = calculator.mul(res, Double.valueOf(a));
        }
        return  a;
    }

    public double midValue(double a, double b){
        double sub  = calculator.sub(a, b);
        double midValue = calculator.div(sub, Double.valueOf(2));
        return midValue;
    }

    public double fahrenheitToCelsius(double fahrenheit){
        double baseSubtraction = calculator.sub(fahrenheit, Double.valueOf(32));
        double baseMultiplication = calculator.mul(baseSubtraction, Double.valueOf(5));
        double baseDivision = calculator.div(baseMultiplication, Double.valueOf(9));
        return baseDivision;
    }
}
