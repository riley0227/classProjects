package edu.sdsu.cs160l;

/**
 * Locate 2 todos
 *  1) Calculator Interface
 *  2) Math Operations class
 */
public class Main {
}
