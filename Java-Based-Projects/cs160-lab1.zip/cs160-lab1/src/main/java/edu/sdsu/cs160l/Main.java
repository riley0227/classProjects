package edu.sdsu.cs160l;

public class Main {
    public static void main(String[] args) {

        if(args!=null){
            for(String arg : args){
                System.out.println(arg);
            }
        }

        System.out.println("Hello world!!");
    }
}
