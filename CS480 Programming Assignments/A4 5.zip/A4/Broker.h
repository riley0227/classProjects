/*

I the undersigned promise that the submitted assignment is my own work. While I was
free to discuss ideas with others, the work contained is my own. I recognize that
should this not be the case; I will be subject to penalties as outlined in the course
syllabus.
Name: Riley Thompson
Red ID: 826526487

*/
#ifndef BROKER_H
#define BROKER_H

#include <queue>
#include <semaphore.h>
#include "fooddelivery.h"
#include <array>
#include <iostream>
using namespace std;


class Broker {
public:
    // constructor
    Broker(int totalRequestsToProcess);
    // destructor
    ~Broker();

    //total number of reqeusts to process
    int totalRequestsToProcess;
    // Queue storing pointers to Request objects(the buffer)
    std::queue<RequestType*> queue;
    // Semaphore for total available slots in the queue, tracks the number of items unconsumed, and mutual exclusion for accessing and changing shared resources.
    sem_t availableSlotsTotal, unconsumed, mutex, availableSandoSlots, endMain, countMutex;

    // Track the number of requests produced and consumed of each type, then number of each type of request currently in the queue.
    std::array<unsigned int, RequestTypeN> produced;
    std::array<unsigned int, RequestTypeN> consumedA;
    std::array<unsigned int, RequestTypeN> consumedB;
    std::array<unsigned int, RequestTypeN> inQueue;

    // counts for total number of reqeusts produced and consumed
    int producedCount;
    int consumedCount;
    
};

#endif 
