
/*

I the undersigned promise that the submitted assignment is my own work. While I was
free to discuss ideas with others, the work contained is my own. I recognize that
should this not be the case; I will be subject to penalties as outlined in the course
syllabus.
Name: Riley Thompson
Red ID: 826526487

*/
#ifndef CONSUMER_H
#define CONSUMER_H

#include <string>
#include <thread>
#include <chrono>
#include "Broker.h"  
#include "fooddelivery.h"

class Consumer {
public:
    // pointer to the broker object
    Broker* broker;
    // the type of consumer and the type of request
    ConsumerType cType;
    RequestType rType;
    // time in milliseconds the consumer waits after processing a request
    int sleep;

    // constructor for consumer class
    Consumer(Broker* broker, ConsumerType cType, int sleep){
        // initializes consumer with broker, consumer type, and sleep time.
        this->broker = broker;
        this->cType = cType;
        this->sleep = sleep;
    }

    // Static function for consumer threads and is how they consume requests and the fucntion is passed to thread to consume requests
    static void *consumeFood(void *ptr);

};

#endif 