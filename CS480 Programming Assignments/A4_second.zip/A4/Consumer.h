#ifndef CONSUMER_H
#define CONSUMER_H

#include <string>
#include <thread>
#include <chrono>
#include "Broker.h"  
#include "fooddelivery.h"

class Consumer {
public:
    // pointer to the broker object
    Broker* broker;
    // the type of consumer and the type of request
    ConsumerType cType;
    RequestType rType;
    // time in milliseconds the consumer waits after processing a request
    int sleep;

    // constructor for consumer class
    Consumer(Broker* broker, ConsumerType cType, int sleep){
        // initializes consumer with broker, consumer type, and sleep time.
        this->broker = broker;
        this->cType = cType;
        this->sleep = sleep;
    }

    // Static function for consumer threads and is how they consume requests and the fucntion is passed to thread to consume requests
    static void *consumeFood(void *ptr);

};

#endif // CONSUMER_H