#include "Consumer.h"
#include "Broker.h"
#include "log.h"
#include <time.h>
#include "fooddelivery.h"
#include <iostream>
using namespace std;

// for consumer thread
void *Consumer::consumeFood(void *ptr) {
    // Cast the void pointer to a Consumer pointer
    Consumer *consumer = (Consumer *)ptr;

    // sets up sleep time struct, Convert milliseconds to seconds then to nanoseconds
    struct timespec sleepTime;
    sleepTime.tv_sec = consumer->sleep / 1000;
    sleepTime.tv_nsec = (consumer->sleep % 1000) * 1000000L;

    // gets broker instance from the consumer
    Broker* broker = consumer->broker;

    cout << broker->producedCount << " " << broker->totalRequestsToProcess << endl;

    while(true) {
        cout << "inside cons while" << endl;
        cout << broker->producedCount << " " << broker->totalRequestsToProcess << endl;
        
        // Wait if there are no unconsumed items in the queue
        sem_wait(&(broker->unconsumed));

        // gets mutex to ensure exclusive access to shared resources
        sem_wait(&(broker->mutex));

        // goes if items are in queue
        if (!broker->queue.empty()) {
            // gets request from front of queue and removes from queue
            RequestType* req = broker->queue.front();
            broker->queue.pop();

            // increment the consumed to add the consumed type and decriment whats in queue
            broker->consumed[consumer->cType]++;
            broker->inQueue[consumer->rType]--;
            
            // puts in the information for RequestRemoved
            RequestRemoved requestRemoved;
            requestRemoved.consumer = consumer->cType;
            requestRemoved.type = consumer->rType;
            requestRemoved.consumed = broker->consumed.data();
            requestRemoved.inBrokerQueue = broker->inQueue.data();

            // logs the removed request
            log_removed_request(requestRemoved);

            // Releases the mutex and update the available slots in the queue
            sem_post(&(broker->mutex));
            sem_post(&(broker->availableSlotsTotal));

            // If consumed item is a sandwich post to the sandwich semaphore
            if (consumer->rType == Sandwich) {
                sem_post(&(broker->availableSandoSlots));
            }
            // free memory of request object and increment consumed requests
            delete req;
            broker->consumedCount++;

            // Sleep for the specified amount of time
            nanosleep(&sleepTime, nullptr);
        }

        // Check if all requests are consumed and the queue is empty, then exit loop
        if(((broker->consumedCount) >= (broker->totalRequestsToProcess)) && (broker->queue.empty())) {
            break;
        }
        cout << "back of cons loop" << endl;
    }
    cout << "endwhile cons" << endl;
    cout << broker->consumedCount << " " << broker->totalRequestsToProcess << endl;
    // Post to the endMain semaphore which means consumer is done processing and main thread can stop
    sem_post(&(broker->endMain));
    return NULL;
}