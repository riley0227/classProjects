//pizza or sando
//time it takes to produce
//access to broker
//integer mili
//broker pointer
//reqeust type value
//counter for sandwich proudces - total pizza cons and sand and prod 
//active(in the nuffer at moment counter)
//every time reqeust gets added, prints
//every time consumed prints too.
//queue that has current types in nuffer

#ifndef PRODUCER_H
#define PRODUCER_H

#include <string>
#include <thread>
#include <chrono>
#include "Broker.h"  
#include "fooddelivery.h"

class Producer {
public:
    // pointer to the broker object
    Broker* broker;
    // the type of request
    RequestType rType;
    // time in milliseconds the producer waits before processing a request(making food)
    int sleep;

    // constructor for producer class
    Producer(Broker* broker, RequestType rType, int sleep){
        // initializes producer with broker, request type, and sleep time.
        this->broker = broker;
        this->rType = rType;
        this->sleep = sleep;
    }

    // Static function for producer threads and is how they produce requests and the fucntion is passed to thread to produce requests
    static void *produceFood(void *ptr);

};

#endif // PRODUCER_H
