//
// Created by Riley Thompson
// RedID: 826526487
//
// add aphidavix

#include <cstdio>
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <vector>
#include <getopt.h>
#include "Broker.h"
#include "Producer.h"
#include "Consumer.h"
#include "log.h"
#include <array>

using namespace std;

#define NORMAL_EXIT 0
#define DEFAULT_REQUESTS 100
#define DEFAULT_MILLISECONDS 0

int main(int argc, char **argv) {
    // Total number of delivery requests
    int totalDelRequests = DEFAULT_REQUESTS; 
    // Time to process request by service A and B
    int timeConsDelivA = DEFAULT_MILLISECONDS;  
    int timeConsDelivB = DEFAULT_MILLISECONDS;
    // Time to produce a pizza or sandwich request
    int timeProducePizza = DEFAULT_MILLISECONDS;  
    int timeProduceSando = DEFAULT_MILLISECONDS;

    // getopt loop to process command line arguments
    int opt;
    while ((opt = getopt(argc, argv, "n:a:b:p:s:")) != -1) {
        switch (opt) {
            // total number of delivery requests
            case 'n':
                totalDelRequests = stoi(optarg);
                break;
            // time for service A to consume a request
            case 'a': 
                timeConsDelivA = stoi(optarg);
                break;
            // time for service B to consume a request
            case 'b': 
                timeConsDelivB = stoi(optarg);
                break;
            // time to produce a pizza request
            case 'p': 
                timeProducePizza = stoi(optarg);
                break;
            // time to produce a sandwich request
            case 's':
                timeProduceSando = stoi(optarg);
                break;
            default: 
                // if unreconginzed option, returns 1
                return 1;
        }
    }
    // creates new Broker with total number of delivery requests
    Broker *broker = new Broker(totalDelRequests);

    // // total number of requests would now be total delivery requests, either 0, or what was given from args
    // broker->totalRequestsToProcess = totalDelRequests;
    
    // creates producer objects for pizza and sandwich requests, specifying broker, request type, and production times.
    Producer* producerPizza = new Producer(broker, Pizza, timeProducePizza);
    Producer* producerSando = new Producer(broker, Sandwich, timeProduceSando);
    // creates consumer objects for pizza and sandwich requests, specifying broker, consumer type, and delivery/consumtion times.
    Consumer* consumerA = new Consumer(broker, DeliveryServiceA, timeConsDelivA);
    Consumer* consumerB = new Consumer(broker, DeliveryServiceB, timeConsDelivB);

    // thread identifiers for producers(produce sandwhiches and produce pizzas) and consumers(delivery service a and b)
    pthread_t prodSando, prodPizza, consA, consB;
    
    // sem_init(&(broker->mutex), 0, 1);                 // Mutex semaphore initialized to 1
    // sem_init(&(broker->availableSlotsTotal), 0, 20);                // 20 empty slots in the queue
    // sem_init(&broker->unconsumed, 0, 0);                  // 0 full slots initially
    // sem_init(&(broker->availableSandoSlots), 0, 8); 
    // sem_init(&broker->endMain, 0, 0);


    //cout << "Producer thread starting" << endl;
    // Start the producer thread for pizza and sandwich requests.  Both will run produceFood function specifying producer Pizza or Producer Sandwhich
    pthread_create(&prodPizza, nullptr, Producer::produceFood, producerPizza);
    //cout << "Producer thread finishing" << endl;
    pthread_create(&prodSando, nullptr, Producer::produceFood, producerSando);
    // Start the consumer thread for delivery service a and delivery service b, called consumerA and B.  Both will run consumeFood function specifying as delivery service A or B
    pthread_create(&consA, nullptr, &Consumer::consumeFood, consumerA);
    pthread_create(&consB, nullptr, &Consumer::consumeFood, consumerB);
    // pthread_create(&consB, nullptr, &Consumer::consumeFood, consumerB);

    // block the main thread until consumer threads say completed(sem_post(&(broker->endMain));)
    sem_wait(&broker->endMain);

    // array of pointers for consume counts for each consumer and request type
    unsigned int *consumed[ConsumerTypeN];
    for (int i = 0; i < ConsumerTypeN; i++) {
        // adds consumed array with pointers to the consumed counts from the broker
        consumed[i] = broker->consumed.data() + i * RequestTypeN;
    }

    // log the produced and consumed history
    log_production_history(broker->produced.data(), consumed);
    
    // delete objects to clean
    delete broker;
    delete producerPizza;
    delete producerSando;
    delete consumerA;
    delete consumerB;
    return 0;
}
