// queue, max reqeusts, semaphores
//initialize value in semaphore to 8
//sem wait pauses till open
//the five semphores are ending main., mutex, availible slots, unconsumed, unconsumed items, availbel sandwhcih slots
// post adds one/simulates another spot avialible.
//init

