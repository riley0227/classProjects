#ifndef BROKER_H
#define BROKER_H

#include <queue>
#include <semaphore.h>
#include "fooddelivery.h"
#include <array>
#include <iostream>
using namespace std;


class Broker {
public:
    //int testreq = 100;
    //total number of reqeusts to process
    int totalRequestsToProcess;
    // Queue storing pointers to Request objects(the buffer)
    std::queue<RequestType*> queue;
    // Semaphore for total available slots in the queue, tracks the number of items unconsumed, and mutual exclusion for accessing and changing shared resources.
    sem_t availableSlotsTotal, unconsumed, mutex, availableSandoSlots, endMain;

    // Track the number of requests produced and consumed of each type, then number of each type of request currently in the queue.
    std::array<unsigned int, RequestTypeN> produced;
    std::array<unsigned int, RequestTypeN> consumed;
    std::array<unsigned int, RequestTypeN> inQueue;

    // counts for total number of reqeusts produced and consumed
    int producedCount;
    int consumedCount;
    
    // put into cpp
    Broker(int totalRequestsToProcess) {
        //cout << "in here" << endl;
        // initializes semaphores, mutual exclusion, availibleSlotsTotal with 20 empty slots to start, available sandwich slots with limit of 8, and one to control end of main thread
        sem_init(&mutex, 0, 1);
        sem_init(&availableSlotsTotal, 0, 20);
        sem_init(&unconsumed, 0, 0);
        sem_init(&availableSandoSlots, 0, 8); 
        sem_init(&endMain, 0, 0);

        // Set initial counts of produced and consumed requests to 0, and total reuests to the value passed in.
        this->producedCount = 0;
        this->consumedCount = 0;
        this->totalRequestsToProcess = totalRequestsToProcess;
    }
    // ~Broker() {
    //     sem_destroy(&mutex);
    //     sem_destroy(&availableSlotsTotal);
    //     sem_destroy(&unconsumed);
    //     sem_destroy(&availableSandoSlots);
    // }
};

#endif // BROKER_H
