#include "Producer.h"
#include "Broker.h"
#include "log.h"
#include <time.h>
#include "fooddelivery.h"
#include <iostream>
using namespace std;

void *Producer::produceFood(void *ptr) {
    // Cast the void pointer to a producer pointer
    Producer *producer = (Producer *)ptr;

    // sets up sleep time struct, Convert milliseconds to seconds then to nanoseconds
    struct timespec sleepTime;
    sleepTime.tv_sec = producer->sleep / 1000;
    sleepTime.tv_nsec = (producer->sleep % 1000) * 1000000L;

    // gets broker instance from the producer
    Broker* broker = producer->broker;

    while(true) {
        // Check if all requests are produced, then exit loop.
        if((broker->producedCount) >= (broker->/*testreq*/totalRequestsToProcess) - 1) {
            break;
        }

        //cout << "inside prod while" << endl;
        //cout << broker->consumedCount << " " << broker->/*testreq*/totalRequestsToProcess << endl;

        // Sleep for the specified amount of time
        nanosleep(&sleepTime, nullptr);

        // Wait for the available sandwich slots if the reqeust type is sandwich
        if (producer->rType == Sandwich) {
            sem_wait(&(producer->broker->availableSandoSlots));
        }

        // Wait if the queue is full
        sem_wait(&(broker->availableSlotsTotal));

        // gets mutex to ensure exclusive access to shared resources
        sem_wait(&(broker->mutex));

        // creates a new request from producer request type and adds it to queue
        RequestType* req = new RequestType(producer->rType);
        broker->queue.push(req);

        // increment the produced to add the produced type and increment whats in queue
        broker->produced[producer->rType]++;
        broker->inQueue[producer->rType]++;

        // puts in the information for RequestAdded
        RequestAdded requestAdded;
        requestAdded.type = producer->rType;
        requestAdded.produced = broker->produced.data();
        requestAdded.inBrokerQueue = broker->inQueue.data();

        // logs the added request
        log_added_request(requestAdded);

        // Releases the mutex and update so show been added to the unconsumed queue
        sem_post(&(broker->mutex));
        sem_post(&(broker->unconsumed));

        // If the item produced was a sandwich, also post to the sandwich slots semaphore.
        if (producer->rType == Sandwich) {
            sem_post(&(broker->availableSandoSlots));
        }
        
        // increment produced requests
        broker->producedCount++;
        //cout << "back of cons loop" << endl;
    }
    //cout << "endwhile cons" << endl;
    //cout << broker->producedCount << " " << broker->/*testreq*/totalRequestsToProcess << endl;
    return NULL;
}